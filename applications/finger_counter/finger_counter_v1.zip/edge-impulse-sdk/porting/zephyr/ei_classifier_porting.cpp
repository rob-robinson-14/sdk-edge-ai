/* The Clear BSD License
 *
 * Copyright (c) 2025 EdgeImpulse Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted (subject to the limitations in the disclaimer
 * below) provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 *   * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 *   * Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY
 * THIS LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "../ei_classifier_porting.h"
#if EI_PORTING_ZEPHYR == 1

#include <version.h>
// Zpehyr 3.1.x and newer uses different include scheme
#if (KERNEL_VERSION_MAJOR > 3) || ((KERNEL_VERSION_MAJOR == 3) && (KERNEL_VERSION_MINOR >= 1))
#include <zephyr/kernel.h>
#include <zephyr/sys_clock.h>
#include <zephyr/drivers/uart.h>
#else
#include <zephyr.h>
#include <drivers/uart.h>
#endif
#include <stdio.h>
#include <stdlib.h>

extern const struct device *uart;

#define EI_WEAK_FN __attribute__((weak))

EI_WEAK_FN EI_IMPULSE_ERROR ei_run_impulse_check_canceled() {
    return EI_IMPULSE_OK;
}

EI_WEAK_FN EI_IMPULSE_ERROR ei_sleep(int32_t time_ms) {
    k_msleep(time_ms);
    return EI_IMPULSE_OK;
}

uint64_t ei_read_timer_ms() {
    return k_uptime_get();
}

uint64_t ei_read_timer_us() {
#if defined(CONFIG_TIMER_HAS_64BIT_CYCLE_COUNTER)
    uint64_t cycles = k_cycle_get_64();
    uint64_t freq = sys_clock_hw_cycles_per_sec();
    return(uint64_t)((cycles * 1000000ULL) / freq);
#else
    return k_uptime_get() * 1000;
#endif
}


EI_WEAK_FN char ei_getchar()
{
    uint8_t rcv_char = 0;
    if (uart_fifo_read(uart, &rcv_char, 1) == 1) {
        return rcv_char;
    }
    else {
        return 0;
    }
}

/**
 *  Printf function uses vsnprintf and output using Arduino Serial
 */
EI_WEAK_FN void ei_printf(const char *format, ...) {
    static char print_buf[1024] = { 0 };

    va_list args;
    va_start(args, format);
    int r = vsnprintf(print_buf, sizeof(print_buf), format, args);
    va_end(args);

    if(r > 0) {
        printf("%s", print_buf);
    }
}

EI_WEAK_FN void ei_printf_float(float f) {
    printf("%f", f);
}

#if !defined(CONFIG_EDGE_IMPULSE_HEAP_TYPE) || (CONFIG_EDGE_IMPULSE_HEAP_TYPE == 0) // malloc

EI_WEAK_FN void *ei_malloc(size_t size) {
    return malloc(size);
}

EI_WEAK_FN void *ei_calloc(size_t nitems, size_t size) {
    return calloc(nitems, size);
}

EI_WEAK_FN void ei_free(void *ptr) {
    free(ptr);
}

#elif defined(CONFIG_EDGE_IMPULSE_HEAP_TYPE) && (CONFIG_EDGE_IMPULSE_HEAP_TYPE == 1)    // k_malloc

#if not defined(CONFIG_HEAP_MEM_POOL_SIZE) || (CONFIG_HEAP_MEM_POOL_SIZE == 0)
#error "CONFIG_HEAP_MEM_POOL_SIZE must be set to a non-zero value when using CONFIG_EDGE_IMPULSE_HEAP_TYPE=1"
#endif

EI_WEAK_FN void *ei_malloc(size_t size) {
    return k_malloc(size);
}

EI_WEAK_FN void *ei_calloc(size_t nitems, size_t size) {
    return k_calloc(nitems, size);
}

EI_WEAK_FN void ei_free(void *ptr) {
    k_free(ptr);
}

#endif

#if defined(__cplusplus) && EI_C_LINKAGE == 1
extern "C"
#endif
EI_WEAK_FN void DebugLog(const char* s) {
    printk("%s", s);
}

#endif // #if EI_PORTING_ZEPHYR == 1